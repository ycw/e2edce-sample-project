console.log(new class{constructor(s=0,o=0){this.isVector2=!0,this.x=s,this.y=o}}(0,1));
